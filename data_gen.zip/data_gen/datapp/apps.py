from django.apps import AppConfig


class DatappConfig(AppConfig):
    name = 'datapp'
