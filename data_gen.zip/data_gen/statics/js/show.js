function guid() {
    p.value = 'GUID';
}

function rownumber() {
    p.value = 'Row Number';
}

function firstname() {
    p.value = 'First Name';
}

function lastname() {
    p.value = 'Last Name';
}

function fullname() {
    p.value = 'Full Name';
}

function firstnamemale() {
    p.value = 'First Name(male)';
}

function firstnamefemale() {
    p.value = 'First Name(female)';
}

function email() {
    p.value = 'Email';
}

function ipaddress4() {
    p.value = 'Ip address v4';
}

function ipaddress6() {
    p.value = 'Ip address v6';
}

function username() {
    p.value = 'Username';
}

function companyname() {
    p.value = 'Comapny Name';
}

function jobtitle() {
    p.value = 'Job Title';
}

function language() {
    p.value = 'Language';
}

function programming() {
    p.value = 'Programming Language';
}

function currency() {
    p.value = 'Currency';
}

function symbol() {
    p.value = 'Currency Symbol';
}

function number() {
    p.value = 'Number';
}

function phone() {
    p.value = 'Phone Number';
}


function domainname() {
    p.value = 'Domain Name';
}


var p;

function selector(inputTag) {
    p = inputTag;
};