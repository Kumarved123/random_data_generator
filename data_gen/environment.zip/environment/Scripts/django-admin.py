#!c:\users\ved\desktop\submission\random_data_generator\data_gen\environment\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
